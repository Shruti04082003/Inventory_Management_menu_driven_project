/**
 * 
 */
/**
 * 
 */
module inventory_management {
	requires java.sql;
}